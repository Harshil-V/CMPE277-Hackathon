from flask import Flask, request, jsonify
from openai import OpenAI
import time
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)

openai_api_key = os.getenv('API_KEY')

ASSISTANT_ID = os.getenv('ASSISTANT_ID')

client = OpenAI(api_key=openai_api_key)

@app.route('/ask', methods=['POST'])
def ask_openai():
  
    data = request.json
    prompt = data.get('prompt')
    
    if not prompt:
        return jsonify({"error": "No prompt provided"}), 400

    try:
       
        thread = client.beta.threads.create(
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=ASSISTANT_ID)

        while run.status != "completed":
            run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
            time.sleep(1)

        message_response = client.beta.threads.messages.list(thread_id=thread.id)
        messages = message_response.data

        latest_message = messages[0] 
        response = latest_message.content[0].text.value

        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)









































# ==================================================
# import time
# from openai import OpenAI

# ASSISTANT_ID = "asst_mtpVKn9JHIKyzjJTHvK765c8"
# client = OpenAI(api_key = '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')

# thread = client.beta.threads.create(
#     messages=[
#         {
#             "role": "user",
#             "content": "What is economic conditions of State and Central Government?"
#         }
#     ]
# )

# run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=ASSISTANT_ID)
# print(f"Run Created: {run.id}")

# while run.status != "completed":
#     run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
#     print(f"Run Status: {run.status}")
#     time.sleep(1)
# else:
#     print(f"Run Completed")


# message_response = client.beta.threads.messages.list(thread_id=thread.id)
# messages = message_response.data

# latest_message = messages[0]
# print(f"Response: {latest_message.content[0].text.value}")

